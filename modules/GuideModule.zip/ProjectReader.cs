﻿using System.Collections.Generic;
using System.IO;

namespace ScriptEase.GuideModule
{
    /// <summary>
    /// 项目文件读取器
    /// </summary>
    public class ProjectReader
    {
        public static List<ProjectFile> ReadAllFiles(string projectPath, int maxFiles = 20)
        {
            var files = new List<ProjectFile>();
            if (!Directory.Exists(projectPath)) return files;

            var allFiles = Directory.GetFiles(projectPath, "*", SearchOption.AllDirectories);
            int count = 0;

            foreach (var file in allFiles)
            {
                string ext = Path.GetExtension(file).ToLower();
                if (ext != ".cs" && ext != ".xaml" && ext != ".json" && ext != ".md" && ext != ".txt")
                    continue;

                files.Add(new ProjectFile
                {
                    RelativePath = file.Replace(projectPath, "").TrimStart('\\', '/'),
                    Content = File.ReadAllText(file),
                    Extension = ext
                });

                count++;
                if (count >= maxFiles) break;
            }
            return files;
        }
    }

    public class ProjectFile
    {
        public string RelativePath { get; set; } = "";
        public string Content { get; set; } = "";
        public string Extension { get; set; } = "";
    }
}