﻿#nullable enable
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ScriptEase.GuideModule
{
    public class GuideModule : ScriptEase.Core.IScriptEaseModule
    {
        public string ModuleName => "ScriptEase 引导助手";
        public string Version => "1.0.0";
        public string AuthorName => "凌空SkyBound · 夏昇KCC · 溯";
        public string Description => "新手引导模块，帮你快速上手 ScriptEase Hub 及模块开发";
        public bool RequiresNetworkAccess => true;
        public string NetworkPurpose => "调用 DeepSeek API 提供代码建议和引导问答";

        private ScriptEase.Core.ICoreServices? _coreServices;
        private GuideWindow? _guideWindow;

        public void Initialize(ScriptEase.Core.ICoreServices services)
        {
            _coreServices = services;
        }

        public UserControl GetModuleUI()
        {
            var button = new Button
            {
                Content = "🚀 打开 ScriptEase 引导助手",
                Background = new SolidColorBrush(Color.FromRgb(37, 110, 186)),
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Height = 42,
                Width = 280,
                Cursor = System.Windows.Input.Cursors.Hand
            };

            button.Click += (s, e) =>
            {
                if (_guideWindow == null || !_guideWindow.IsLoaded)
                {
                    _guideWindow = new GuideWindow(_coreServices);
                    _guideWindow.Closed += (_, _) => _guideWindow = null;
                    _guideWindow.Show();
                }
                else
                {
                    _guideWindow.Activate();
                }
            };

            var container = new Grid();
            container.Children.Add(button);
            return container;
        }
    }
}