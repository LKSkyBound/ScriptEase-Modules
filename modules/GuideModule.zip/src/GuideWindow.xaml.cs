﻿#nullable enable
using System.Windows;

namespace ScriptEase.GuideModule
{
    public partial class GuideWindow : Window
    {
        private ScriptEase.Core.ICoreServices? _coreServices;

        public GuideWindow(ScriptEase.Core.ICoreServices? coreServices)
        {
            InitializeComponent();
            _coreServices = coreServices;

            WelcomeOverlayControl.StartWorking += (s, e) =>
            {
                WelcomeOverlayControl.Visibility = Visibility.Collapsed;
                ChatPanelControl.Visibility = Visibility.Visible;
                ChatPanelControl.SetCoreServices(_coreServices);
                ChatPanelControl.ShowWelcome();
                this.Height = 400;
                this.Width = 500;
            };

            WelcomeOverlayControl.QuickQuestionClicked += (question) =>
            {
                WelcomeOverlayControl.Visibility = Visibility.Collapsed;
                ChatPanelControl.Visibility = Visibility.Visible;
                ChatPanelControl.SetCoreServices(_coreServices);
                ChatPanelControl.ShowWelcome();
                ChatPanelControl.SendQuickQuestion(question);
                this.Height = 400;
                this.Width = 500;
            };

            ChatPanelControl.MinimizeRequested += (s, e) =>
            {
                this.WindowState = WindowState.Minimized;
            };
        }
    }
}