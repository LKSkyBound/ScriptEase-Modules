﻿#nullable enable
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ScriptEase.GuideModule
{
    public partial class ChatPanel : UserControl
    {
        private ScriptEase.Core.ICoreServices? _coreServices;
        private string? _projectPath;

        public event RoutedEventHandler? MinimizeRequested;

        public ChatPanel()
        {
            InitializeComponent();
            _projectPath = DetectProjectPath();
        }

        public void SetCoreServices(ScriptEase.Core.ICoreServices? services)
        {
            _coreServices = services;
        }

        public void ShowWelcome()
        {
            AddChatMessage("溯", "我已准备就绪！有什么不懂的随时问我。", true);
        }

        public void SendQuickQuestion(string question)
        {
            ChatInputBox.Text = question;
            SendMessage();
        }

        private string? DetectProjectPath()
        {
            string modulePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string? dir = Path.GetDirectoryName(modulePath);
            while (dir != null)
            {
                if (File.Exists(Path.Combine(dir, "manifest.json")))
                    return dir;
                dir = Path.GetDirectoryName(dir);
            }
            return null;
        }

        private void MinimizeChat_Click(object sender, RoutedEventArgs e)
        {
            MinimizeRequested?.Invoke(this, e);
        }

        private void ChatInputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && ChatInputBox.IsKeyboardFocused)
            {
                if (Keyboard.Modifiers == ModifierKeys.Shift) return;
                e.Handled = true;
                SendMessage();
            }
        }

        private void SendChatButton_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private async void SendMessage()
        {
            string message = ChatInputBox.Text.Trim();
            if (string.IsNullOrEmpty(message)) return;

            ChatInputBox.Text = "";
            AddChatMessage("你", message, false);
            AddChatMessage("溯", "思考中...", true);

            string projectContext = GetProjectContext();
            string systemPrompt = "你是溯，ScriptEase 引导助手。你的任务是帮助开发者解决模块开发中的问题。" +
                                  "以下是当前项目的文件结构：\n" + projectContext +
                                  "\n请基于项目文件内容提供准确的代码建议。回答简洁、专业、友好。";

            if (_coreServices != null)
            {
                string response = await _coreServices.CallDeepSeekAPI(systemPrompt, message);
                if (ChatMessagesPanel.Children.Count > 0)
                    ChatMessagesPanel.Children.RemoveAt(ChatMessagesPanel.Children.Count - 1);
                AddChatMessage("溯", response, true);
            }
            else
            {
                if (ChatMessagesPanel.Children.Count > 0)
                    ChatMessagesPanel.Children.RemoveAt(ChatMessagesPanel.Children.Count - 1);
                AddChatMessage("溯", "抱歉，我暂时无法连接到 AI 服务。请确认 API Key 已正确设置。", true);
            }
        }

        private string GetProjectContext()
        {
            if (_projectPath == null) return "未检测到项目路径。";
            try
            {
                var files = Directory.GetFiles(_projectPath, "*", SearchOption.AllDirectories)
                    .Where(f => f.EndsWith(".cs") || f.EndsWith(".xaml") || f.EndsWith(".json") || f.EndsWith(".md"))
                    .Take(10);
                string context = "";
                foreach (var file in files)
                {
                    string relativePath = file.Replace(_projectPath, "").TrimStart('\\');
                    string content = File.ReadAllText(file);
                    if (content.Length > 500) content = content.Substring(0, 500) + "...";
                    context += "--- " + relativePath + " ---\n" + content + "\n\n";
                }
                return context;
            }
            catch { return "无法读取项目文件。"; }
        }

        private void AddChatMessage(string sender, string text, bool isBot)
        {
            var bubble = new Border
            {
                Background = isBot
                    ? new SolidColorBrush(Color.FromRgb(235, 240, 250))
                    : new SolidColorBrush(Color.FromRgb(245, 245, 245)),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(10, 6, 10, 6),
                Margin = new Thickness(isBot ? 0 : 40, 3, isBot ? 40 : 0, 3),
                HorizontalAlignment = isBot ? HorizontalAlignment.Left : HorizontalAlignment.Right,
                MaxWidth = 380
            };

            var stack = new StackPanel();
            stack.Children.Add(new TextBlock
            {
                Text = sender,
                Foreground = new SolidColorBrush(Color.FromRgb(37, 110, 186)),
                FontSize = 10,
                FontWeight = FontWeights.Bold
            });
            stack.Children.Add(new TextBlock
            {
                Text = text,
                Foreground = new SolidColorBrush(Color.FromRgb(51, 51, 51)),
                FontSize = 12,
                TextWrapping = TextWrapping.Wrap
            });

            bubble.Child = stack;
            ChatMessagesPanel.Children.Add(bubble);
            ChatScrollViewer.ScrollToBottom();
        }
    }
}