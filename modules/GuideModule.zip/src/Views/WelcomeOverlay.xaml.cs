﻿#nullable enable
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ScriptEase.GuideModule
{
    public partial class WelcomeOverlay : UserControl
    {
        public event RoutedEventHandler? StartWorking;
        public event Action<string>? QuickQuestionClicked;

        public WelcomeOverlay()
        {
            InitializeComponent();
        }

        private void StartWorking_Click(object sender, RoutedEventArgs e)
        {
            StartWorking?.Invoke(this, e);
        }

        private void QuickQuestion1_Click(object sender, MouseButtonEventArgs e)
        {
            QuickQuestionClicked?.Invoke("如何创建项目文件？");
        }

        private void QuickQuestion2_Click(object sender, MouseButtonEventArgs e)
        {
            QuickQuestionClicked?.Invoke("这个代码报错怎么解决？");
        }

        private void QuickQuestion3_Click(object sender, MouseButtonEventArgs e)
        {
            QuickQuestionClicked?.Invoke("帮我写一个基础的模块结构");
        }
    }
}